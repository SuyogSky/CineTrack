import { Request, Response, NextFunction } from 'express';
import { TmdbService } from '../services/tmdb.service';
import { movieSearchQuerySchema } from '../validators/movie.validator';
import { sendSuccess } from '../utils/response';
import { MovieService } from '../services/movie.service';

export class MovieController {
  static async search(req: Request, res: Response, next: NextFunction) {
    try {
      const { q, page } = movieSearchQuerySchema.parse(req.query);
      const results = await TmdbService.searchMovies(q, page);
      sendSuccess(res, results);
    } catch (error) {
      next(error);
    }
  }

  static async getDetails(req: Request, res: Response, next: NextFunction) {
    try {
      const tmdbIdParam = req.params.tmdbId as string;
      const tmdbId = parseInt(tmdbIdParam, 10);
      if (isNaN(tmdbId) || tmdbId <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Invalid TMDb ID parameter',
          code: 'VALIDATION_ERROR',
        });
      }

      const movie = await MovieService.getMovieByTmdbId(tmdbId);
      sendSuccess(res, { movie });
    } catch (error) {
      next(error);
    }
  }
}
