import { prisma } from '../config/database';
import {
  AppError,
  ConflictError,
  ForbiddenError,
  NotFoundError,
} from '../utils/errors';
import {
  CreateCollectionInput,
  UpdateCollectionInput,
} from '../validators/collection.validator';
import { generateShareToken, selectRandomElement } from '../utils/random';

export type UserRoleInCollection = 'OWNER' | 'COLLABORATOR' | 'NONE';

export class CollectionService {
  static async checkCollectionAccess(
    collectionId: string,
    userId: string
  ): Promise<{ role: UserRoleInCollection; collection: any }> {
    const collection = await prisma.collection.findUnique({
      where: { id: collectionId },
      include: {
        owner: {
          select: { id: true, username: true, email: true },
        },
        members: {
          include: {
            user: {
              select: { id: true, username: true, email: true },
            },
          },
        },
      },
    });

    if (!collection) {
      throw new NotFoundError('Collection not found');
    }

    if (collection.ownerId === userId) {
      return { role: 'OWNER', collection };
    }

    const isMember = collection.members.some((m) => m.userId === userId);
    if (isMember) {
      return { role: 'COLLABORATOR', collection };
    }

    return { role: 'NONE', collection };
  }

  static async getUserDefaultWatchlist(userId: string) {
    let watchlist = await prisma.collection.findFirst({
      where: { ownerId: userId, isDefaultWatchlist: true },
      include: {
        movies: {
          include: {
            movie: true,
            adder: { select: { id: true, username: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { movies: true } },
      },
    });

    if (!watchlist) {
      watchlist = await prisma.collection.create({
        data: {
          ownerId: userId,
          title: 'My Watchlist',
          description: 'Personal master watchlist for movies to watch.',
          visibility: 'PRIVATE',
          isDefaultWatchlist: true,
        },
        include: {
          movies: {
            include: {
              movie: true,
              adder: { select: { id: true, username: true } },
            },
            orderBy: { createdAt: 'desc' },
          },
          _count: { select: { movies: true } },
        },
      });
    }

    return watchlist;
  }

  static async listUserCollections(userId: string) {
    const owned = await prisma.collection.findMany({
      where: { ownerId: userId },
      include: {
        owner: { select: { id: true, username: true } },
        _count: { select: { movies: true, members: true } },
      },
      orderBy: [{ isDefaultWatchlist: 'desc' }, { createdAt: 'desc' }],
    });

    const shared = await prisma.collection.findMany({
      where: {
        members: { some: { userId } },
      },
      include: {
        owner: { select: { id: true, username: true } },
        _count: { select: { movies: true, members: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return { owned, shared };
  }

  static async getCollectionById(collectionId: string, userId?: string) {
    const collection = await prisma.collection.findUnique({
      where: { id: collectionId },
      include: {
        owner: { select: { id: true, username: true } },
        members: {
          include: {
            user: { select: { id: true, username: true } },
          },
        },
        movies: {
          include: {
            movie: true,
            adder: { select: { id: true, username: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { movies: true, members: true } },
      },
    });

    if (!collection) {
      throw new NotFoundError('Collection not found');
    }

    // If userId provided, check authorization
    if (userId) {
      const isOwner = collection.ownerId === userId;
      const isMember = collection.members.some((m) => m.userId === userId);
      if (!isOwner && !isMember) {
        throw new ForbiddenError('You do not have access to this collection');
      }
      return {
        ...collection,
        userRole: isOwner ? 'OWNER' : 'COLLABORATOR',
      };
    }

    return collection;
  }

  static async createCollection(userId: string, input: CreateCollectionInput) {
    return prisma.collection.create({
      data: {
        ownerId: userId,
        title: input.title,
        description: input.description,
        visibility: 'PRIVATE',
      },
      include: {
        owner: { select: { id: true, username: true } },
        _count: { select: { movies: true, members: true } },
      },
    });
  }

  static async updateCollection(
    collectionId: string,
    userId: string,
    input: UpdateCollectionInput
  ) {
    const { role, collection } = await this.checkCollectionAccess(collectionId, userId);

    if (role !== 'OWNER') {
      throw new ForbiddenError('Only the collection owner can modify collection details');
    }

    return prisma.collection.update({
      where: { id: collectionId },
      data: {
        ...(input.title !== undefined ? { title: input.title } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
      },
      include: {
        owner: { select: { id: true, username: true } },
        _count: { select: { movies: true, members: true } },
      },
    });
  }

  static async deleteCollection(collectionId: string, userId: string) {
    const { role, collection } = await this.checkCollectionAccess(collectionId, userId);

    if (role !== 'OWNER') {
      throw new ForbiddenError('Only the collection owner can delete the collection');
    }

    if (collection.isDefaultWatchlist) {
      throw new ForbiddenError('Cannot delete your default master watchlist');
    }

    await prisma.collection.delete({
      where: { id: collectionId },
    });

    return { id: collectionId, deleted: true };
  }

  static async enablePublicSharing(collectionId: string, userId: string) {
    const { role } = await this.checkCollectionAccess(collectionId, userId);

    if (role !== 'OWNER') {
      throw new ForbiddenError('Only the collection owner can manage sharing settings');
    }

    const shareToken = generateShareToken();

    return prisma.collection.update({
      where: { id: collectionId },
      data: {
        visibility: 'PUBLIC_LINK',
        shareToken,
      },
      select: {
        id: true,
        title: true,
        visibility: true,
        shareToken: true,
      },
    });
  }

  static async disablePublicSharing(collectionId: string, userId: string) {
    const { role } = await this.checkCollectionAccess(collectionId, userId);

    if (role !== 'OWNER') {
      throw new ForbiddenError('Only the collection owner can manage sharing settings');
    }

    return prisma.collection.update({
      where: { id: collectionId },
      data: {
        visibility: 'PRIVATE',
        shareToken: null,
      },
      select: {
        id: true,
        title: true,
        visibility: true,
        shareToken: true,
      },
    });
  }

  static async getPublicCollectionByToken(shareToken: string) {
    if (!shareToken || shareToken.trim() === '') {
      throw new NotFoundError('Invalid share link');
    }

    const collection = await prisma.collection.findUnique({
      where: { shareToken },
      include: {
        owner: { select: { username: true } },
        movies: {
          include: {
            movie: true,
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { movies: true } },
      },
    });

    if (!collection || collection.visibility !== 'PUBLIC_LINK') {
      throw new NotFoundError('Collection is not available or public sharing has been revoked');
    }

    return {
      id: collection.id,
      title: collection.title,
      description: collection.description,
      ownerUsername: collection.owner.username,
      createdAt: collection.createdAt,
      movies: collection.movies.map((cm) => ({
        id: cm.id,
        movieId: cm.movieId,
        status: cm.status,
        watchedAt: cm.watchedAt,
        note: cm.note,
        createdAt: cm.createdAt,
        movie: cm.movie,
      })),
      totalMovies: collection._count.movies,
    };
  }

  static async getRandomUnwatchedMovie(
    collectionId: string,
    userId: string,
    rng: () => number = Math.random
  ) {
    const { role } = await this.checkCollectionAccess(collectionId, userId);

    if (role === 'NONE') {
      throw new ForbiddenError('You do not have access to this collection');
    }

    const unwatched = await prisma.collectionMovie.findMany({
      where: {
        collectionId,
        status: 'TO_WATCH',
      },
      include: {
        movie: true,
        adder: { select: { id: true, username: true } },
      },
    });

    if (unwatched.length === 0) {
      return null;
    }

    return selectRandomElement(unwatched, rng);
  }
}
