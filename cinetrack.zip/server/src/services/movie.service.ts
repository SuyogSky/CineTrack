import { prisma } from '../config/database';
import { TmdbService } from './tmdb.service';
import { NotFoundError } from '../utils/errors';

export class MovieService {
  static async getOrCreateMovie(tmdbId: number) {
    // 1. Check existing
    let movie = await prisma.movie.findUnique({
      where: { tmdbId },
    });

    if (movie) {
      return movie;
    }

    // 2. Fetch metadata from TMDb service
    const metadata = await TmdbService.getMovieDetails(tmdbId);
    if (!metadata) {
      // Try search if direct get fails
      const searchRes = await TmdbService.searchMovies(String(tmdbId));
      const match = searchRes.items.find((m) => m.tmdbId === tmdbId);
      if (!match) {
        throw new NotFoundError(`Movie with TMDb ID ${tmdbId} not found`);
      }
      movie = await prisma.movie.create({
        data: {
          tmdbId: match.tmdbId,
          title: match.title,
          originalTitle: match.originalTitle,
          overview: match.overview,
          posterPath: match.posterPath,
          backdropPath: match.backdropPath,
          releaseDate: match.releaseDate,
          releaseYear: match.releaseYear,
          originalLanguage: match.originalLanguage,
          popularity: match.popularity,
          voteAverage: match.voteAverage,
          genres: match.genres,
        },
      });
      return movie;
    }

    movie = await prisma.movie.create({
      data: {
        tmdbId: metadata.tmdbId,
        title: metadata.title,
        originalTitle: metadata.originalTitle,
        overview: metadata.overview,
        posterPath: metadata.posterPath,
        backdropPath: metadata.backdropPath,
        releaseDate: metadata.releaseDate,
        releaseYear: metadata.releaseYear,
        originalLanguage: metadata.originalLanguage,
        popularity: metadata.popularity,
        voteAverage: metadata.voteAverage,
        genres: metadata.genres,
      },
    });

    return movie;
  }

  static async getMovieById(id: string) {
    const movie = await prisma.movie.findUnique({
      where: { id },
    });
    if (!movie) {
      throw new NotFoundError('Movie not found');
    }
    return movie;
  }

  static async getMovieByTmdbId(tmdbId: number) {
    let movie = await prisma.movie.findUnique({
      where: { tmdbId },
    });
    if (!movie) {
      movie = await this.getOrCreateMovie(tmdbId);
    }
    return movie;
  }
}
