import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, Film, Plus, Check, Loader2, Star } from 'lucide-react';
import { Modal } from '../common/Modal';
import { movieService } from '../../services/movieService';
import { collectionService } from '../../services/collectionService';
import { Movie } from '../../types';

interface MovieSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetCollectionId?: string;
  onMovieAdded?: () => void;
}

export const MovieSearchModal: React.FC<MovieSearchModalProps> = ({
  isOpen,
  onClose,
  targetCollectionId,
  onMovieAdded,
}) => {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string>(
    targetCollectionId || ''
  );
  const [addedMovieIds, setAddedMovieIds] = useState<Set<number>>(new Set());
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Fetch collections for collection dropdown if targetCollectionId isn't provided
  const { data: collectionsData } = useQuery({
    queryKey: ['collections'],
    queryFn: collectionService.listCollections,
    enabled: isOpen,
  });

  // Watchlist query for default collection ID
  const { data: defaultWatchlist } = useQuery({
    queryKey: ['defaultWatchlist'],
    queryFn: collectionService.getDefaultWatchlist,
    enabled: isOpen && !targetCollectionId,
  });

  useEffect(() => {
    if (targetCollectionId) {
      setSelectedCollectionId(targetCollectionId);
    } else if (defaultWatchlist?.id) {
      setSelectedCollectionId(defaultWatchlist.id);
    }
  }, [targetCollectionId, defaultWatchlist]);

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchTerm.trim());
    }, 350);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Query TMDb search API
  const {
    data: searchResults,
    isLoading: isSearching,
    isError,
  } = useQuery({
    queryKey: ['movieSearch', debouncedQuery],
    queryFn: () => movieService.search(debouncedQuery),
    enabled: isOpen && debouncedQuery.length > 0,
    staleTime: 5 * 60 * 1000,
  });

  // Add movie mutation
  const addMutation = useMutation({
    mutationFn: ({
      colId,
      tmdbId,
    }: {
      colId: string;
      tmdbId: number;
    }) => collectionService.addMovie(colId, { tmdbId }),
    onSuccess: (_, variables) => {
      setAddedMovieIds((prev) => new Set([...prev, variables.tmdbId]));
      queryClient.invalidateQueries({ queryKey: ['collection'] });
      queryClient.invalidateQueries({ queryKey: ['defaultWatchlist'] });
      queryClient.invalidateQueries({ queryKey: ['collections'] });
      if (onMovieAdded) onMovieAdded();
    },
    onError: (error: Error) => {
      setErrorMessage(error.message);
    },
  });

  const handleAdd = (movie: Movie) => {
    const colId = selectedCollectionId || defaultWatchlist?.id;
    if (!colId) {
      setErrorMessage('Please select a collection first');
      return;
    }
    setErrorMessage(null);
    addMutation.mutate({ colId, tmdbId: movie.tmdbId });
  };

  const allCollections = [
    ...(collectionsData?.owned || []),
    ...(collectionsData?.shared || []),
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          <Film className="w-5 h-5 text-red-500" />
          <span>Search & Add Movies</span>
        </div>
      }
      maxWidth="2xl"
    >
      <div className="space-y-4">
        {/* Collection Selector & Search Input */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              autoFocus
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setErrorMessage(null);
              }}
              placeholder="Search by title (e.g. Inception, Dune, Interstellar)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-slate-100 placeholder-zinc-500 focus:outline-none focus:border-red-500/80 transition-colors"
            />
          </div>

          {/* Collection destination dropdown */}
          <select
            value={selectedCollectionId}
            onChange={(e) => setSelectedCollectionId(e.target.value)}
            className="px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-300 focus:outline-none focus:border-red-500/80 transition-colors max-w-xs"
          >
            {defaultWatchlist && (
              <option value={defaultWatchlist.id}>
                ⭐ {defaultWatchlist.title} (Default)
              </option>
            )}
            {allCollections
              .filter((c) => c.id !== defaultWatchlist?.id)
              .map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
          </select>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
            {errorMessage}
          </div>
        )}

        {/* Search Results Container */}
        <div className="max-h-[55vh] overflow-y-auto space-y-2.5 pr-1">
          {isSearching && (
            <div className="py-12 flex flex-col items-center justify-center gap-2 text-zinc-400">
              <Loader2 className="w-6 h-6 animate-spin text-red-500" />
              <p className="text-xs">Searching TMDb movie database...</p>
            </div>
          )}

          {!isSearching && debouncedQuery && searchResults?.items.length === 0 && (
            <div className="py-12 text-center text-zinc-500 text-sm">
              No movies found matching "{debouncedQuery}". Try another title!
            </div>
          )}

          {!debouncedQuery && !isSearching && (
            <div className="py-12 text-center text-zinc-500 text-xs">
              Type a movie title to search millions of films via TMDb.
            </div>
          )}

          {searchResults?.items.map((movie) => {
            const isAdded = addedMovieIds.has(movie.tmdbId);
            const isPending =
              addMutation.isPending &&
              addMutation.variables?.tmdbId === movie.tmdbId;
            const posterUrl = movie.posterPath
              ? `https://image.tmdb.org/t/p/w185${movie.posterPath}`
              : null;

            return (
              <div
                key={movie.tmdbId}
                className="flex items-center gap-3.5 p-2.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-800/60 border border-zinc-800/80 transition-colors"
              >
                {/* Poster */}
                <div className="w-12 h-16 rounded-lg bg-zinc-800 overflow-hidden shrink-0 flex items-center justify-center">
                  {posterUrl ? (
                    <img
                      src={posterUrl}
                      alt={movie.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Film className="w-6 h-6 text-zinc-600" />
                  )}
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-semibold text-slate-100 truncate">
                      {movie.title}
                    </h4>
                    {movie.releaseYear && (
                      <span className="text-xs text-zinc-400">
                        ({movie.releaseYear})
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mt-1 text-xs text-zinc-400">
                    {movie.voteAverage != null && movie.voteAverage > 0 && (
                      <span className="flex items-center gap-1 text-amber-400 font-medium">
                        <Star className="w-3 h-3 fill-amber-400" />
                        {movie.voteAverage.toFixed(1)}
                      </span>
                    )}
                    {movie.genres && movie.genres.length > 0 && (
                      <span className="truncate">
                        • {movie.genres.slice(0, 3).join(', ')}
                      </span>
                    )}
                  </div>

                  {movie.overview && (
                    <p className="text-xs text-zinc-500 line-clamp-1 mt-1">
                      {movie.overview}
                    </p>
                  )}
                </div>

                {/* Add Action Button */}
                <button
                  type="button"
                  data-testid="modal-add-button"
                  disabled={isAdded || isPending}
                  onClick={() => handleAdd(movie)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0 ${
                    isAdded
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'bg-red-600 hover:bg-red-700 text-white shadow-sm'
                  }`}
                >
                  {isPending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : isAdded ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      Added
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      Add
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </Modal>
  );
};
