import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dices, CheckCircle2, RotateCcw, Star, Film, Sparkles, Loader2 } from 'lucide-react';
import { Modal } from '../common/Modal';
import { collectionService } from '../../services/collectionService';
import { CollectionMovie } from '../../types';

interface MovieRouletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  collectionId: string;
  collectionTitle?: string;
}

export const MovieRouletteModal: React.FC<MovieRouletteModalProps> = ({
  isOpen,
  onClose,
  collectionId,
  collectionTitle = 'Collection',
}) => {
  const queryClient = useQueryClient();
  const [selectedEntry, setSelectedEntry] = useState<CollectionMovie | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [emptyMessage, setEmptyMessage] = useState<string | null>(null);

  const fetchRandomMutation = useMutation({
    mutationFn: () => collectionService.getRandomMovie(collectionId),
    onSuccess: (entry) => {
      if (!entry) {
        setSelectedEntry(null);
        setEmptyMessage('No unwatched movies in this collection! Add more or mark some as unwatched.');
      } else {
        setEmptyMessage(null);
        setSelectedEntry(entry);
      }
    },
  });

  const markWatchedMutation = useMutation({
    mutationFn: (entryId: string) =>
      collectionService.updateMovie(collectionId, entryId, { status: 'WATCHED' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['collection', collectionId] });
      queryClient.invalidateQueries({ queryKey: ['defaultWatchlist'] });
      if (selectedEntry) {
        setSelectedEntry({
          ...selectedEntry,
          status: 'WATCHED',
          watchedAt: new Date().toISOString(),
        });
      }
    },
  });

  const spinRoulette = () => {
    setIsSpinning(true);
    setEmptyMessage(null);
    setTimeout(() => {
      fetchRandomMutation.mutate(undefined, {
        onSettled: () => {
          setIsSpinning(false);
        },
      });
    }, 700); // Cinematic spinning delay
  };

  useEffect(() => {
    if (isOpen) {
      spinRoulette();
    } else {
      setSelectedEntry(null);
      setEmptyMessage(null);
    }
  }, [isOpen, collectionId]);

  const movie = selectedEntry?.movie;
  const posterUrl = movie?.posterPath
    ? `https://image.tmdb.org/t/p/w500${movie.posterPath}`
    : null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          <Dices className="w-5 h-5 text-amber-400" />
          <span>Movie Night Roulette — {collectionTitle}</span>
        </div>
      }
      maxWidth="lg"
    >
      <div className="space-y-6 text-center">
        {/* Animated Spin / Loading State */}
        {isSpinning && (
          <div className="py-16 flex flex-col items-center justify-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center animate-spin">
              <Dices className="w-8 h-8 text-amber-400" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-slate-100">
                Finding the Perfect Movie...
              </h4>
              <p className="text-xs text-zinc-400 mt-1">
                Picking randomly from your unwatched films
              </p>
            </div>
          </div>
        )}

        {/* Empty Collection State */}
        {!isSpinning && emptyMessage && (
          <div className="py-12 px-4 space-y-3">
            <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mx-auto text-zinc-500">
              <Film className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-slate-200">
              {emptyMessage}
            </h4>
            <button
              type="button"
              onClick={onClose}
              className="mt-4 px-4 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300 hover:text-white"
            >
              Close
            </button>
          </div>
        )}

        {/* Selected Movie Reveal */}
        {!isSpinning && selectedEntry && movie && (
          <div className="space-y-4">
            <div className="relative mx-auto w-48 aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl shadow-amber-950/30 border-2 border-amber-500/40 glow-cinematic">
              {posterUrl ? (
                <img
                  src={posterUrl}
                  alt={movie.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-zinc-900 text-zinc-600">
                  <Film className="w-10 h-10 mb-2" />
                  <span className="text-xs text-zinc-400">{movie.title}</span>
                </div>
              )}
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                TONIGHT'S PICK
              </div>

              <h3 className="text-xl font-bold text-slate-100">
                {movie.title}
              </h3>

              <div className="flex items-center justify-center gap-2 text-xs text-zinc-400 mt-1">
                <span>{movie.releaseYear || 'Unknown Year'}</span>
                {movie.voteAverage != null && movie.voteAverage > 0 && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-amber-400 font-semibold">
                      <Star className="w-3 h-3 fill-amber-400" />
                      {movie.voteAverage.toFixed(1)}
                    </span>
                  </>
                )}
                {movie.genres && movie.genres.length > 0 && (
                  <>
                    <span>•</span>
                    <span>{movie.genres.slice(0, 2).join(', ')}</span>
                  </>
                )}
              </div>

              {movie.overview && (
                <p className="text-xs text-zinc-400 line-clamp-3 mt-3 px-4 leading-relaxed">
                  {movie.overview}
                </p>
              )}

              {selectedEntry.note && (
                <div className="mt-3 mx-4 p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs text-indigo-300 italic">
                  Note: "{selectedEntry.note}"
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center justify-center gap-3 pt-3">
              <button
                type="button"
                onClick={spinRoulette}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700/80 text-zinc-200 text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Roll Again
              </button>

              {selectedEntry.status !== 'WATCHED' ? (
                <button
                  type="button"
                  disabled={markWatchedMutation.isPending}
                  onClick={() => markWatchedMutation.mutate(selectedEntry.id)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-emerald-950/40"
                >
                  {markWatchedMutation.isPending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  )}
                  Mark as Watched
                </button>
              ) : (
                <span className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Watched!
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
